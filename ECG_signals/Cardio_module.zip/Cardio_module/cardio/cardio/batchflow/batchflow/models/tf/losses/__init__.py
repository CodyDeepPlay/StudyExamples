""" Contains custom losses """
from .core import softmax_cross_entropy
from .dice import *  # pylint: disable=wildcard-import
