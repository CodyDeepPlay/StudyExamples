""" Custom losses """
from .core import CrossEntropyLoss
