""" Open datasets """
from .base import Openset, ImagesOpenset
from .mnist import MNIST
from .cifar import CIFAR10, CIFAR100
