""" Pytest configuration. """
# pylint: disable=invalid-name, unused-import
import pytest

from .config_pass_test import single_config, multi_config, model_and_config
