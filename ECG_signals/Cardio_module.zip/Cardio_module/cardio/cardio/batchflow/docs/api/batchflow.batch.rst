Batch
-----

.. toctree::
   :maxdepth: 2

.. autoclass:: batchflow.Batch
    :members:
    :undoc-members:
