ImagesBatch
-----------

.. toctree::
   :maxdepth: 2

.. autoclass:: batchflow.ImagesBatch
    :inherited-members:
    :members:
    :undoc-members:
    :exclude-members: get_pos
    :show-inheritance:
