Dataset
-------

.. toctree::
   :maxdepth: 2

.. autoclass:: batchflow.Dataset
    :members:
    :undoc-members:
    :inherited-members:
