Decorators
----------

.. toctree::
   :maxdepth: 2


action
======
.. autofunction:: batchflow.action


inbatch_parallel
================
.. autofunction:: batchflow.inbatch_parallel


any_action_failed
=================
.. autofunction:: batchflow.any_action_failed


mjit
====
.. autofunction:: batchflow.mjit
