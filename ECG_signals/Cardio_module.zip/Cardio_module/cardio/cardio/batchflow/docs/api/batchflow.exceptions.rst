Exceptions
----------

.. toctree::
   :maxdepth: 2


SkipBatchException
==================
.. autoclass:: batchflow.SkipBatchException
