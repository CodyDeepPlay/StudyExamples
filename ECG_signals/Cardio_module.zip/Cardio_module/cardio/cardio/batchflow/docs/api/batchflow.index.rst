Index
-----

.. toctree::
   :maxdepth: 2


DatasetIndex
============
.. autoclass:: batchflow.DatasetIndex
    :members:
    :undoc-members:
    :inherited-members:


FilesIndex
==========
.. autoclass:: batchflow.FilesIndex
    :members:
    :undoc-members:
    :show-inheritance:
