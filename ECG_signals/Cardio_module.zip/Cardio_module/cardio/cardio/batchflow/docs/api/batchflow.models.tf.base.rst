=======
TFModel
=======

.. automodule:: batchflow.models.tf.base
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:

.. automethod:: batchflow.models.tf.TFModel._make_inputs
