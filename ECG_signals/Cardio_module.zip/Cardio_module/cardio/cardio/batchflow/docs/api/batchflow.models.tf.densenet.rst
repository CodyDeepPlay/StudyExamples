========
DenseNet
========

.. automodule:: batchflow.models.tf.densenet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
