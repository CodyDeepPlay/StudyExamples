=========================
DenseNet for segmentation
=========================

.. automodule:: batchflow.models.tf.densenet_fc
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
