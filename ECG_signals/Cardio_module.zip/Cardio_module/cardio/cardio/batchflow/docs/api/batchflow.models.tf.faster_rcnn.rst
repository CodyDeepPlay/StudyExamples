===========
Faster RCNN
===========

.. automodule:: batchflow.models.tf.faster_rcnn
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
