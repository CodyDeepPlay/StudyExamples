==========================
Global Convolution Network
==========================

.. automodule:: batchflow.models.tf.gcn
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
