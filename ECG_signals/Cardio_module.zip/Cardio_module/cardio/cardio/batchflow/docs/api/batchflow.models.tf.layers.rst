==========================
batchflow.models.tf.layers
==========================

.. automodule:: batchflow.models.tf.layers
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:
