==========
PyramidNet
==========

.. automodule:: batchflow.models.tf.pyramidnet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
