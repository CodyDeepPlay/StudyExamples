=========
RefineNet
=========

.. automodule:: batchflow.models.tf.refinenet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
