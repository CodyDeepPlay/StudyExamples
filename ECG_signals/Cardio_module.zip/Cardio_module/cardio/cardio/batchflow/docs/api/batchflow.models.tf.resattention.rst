===============
ResNetAttention
===============

.. automodule:: batchflow.models.tf.resattention
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
