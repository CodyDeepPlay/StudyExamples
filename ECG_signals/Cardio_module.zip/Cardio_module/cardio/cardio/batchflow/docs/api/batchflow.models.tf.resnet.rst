======
ResNet
======

.. automodule:: batchflow.models.tf.resnet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
