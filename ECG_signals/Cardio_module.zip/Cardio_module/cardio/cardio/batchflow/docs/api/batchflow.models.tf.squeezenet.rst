==========
SqueezeNet
==========

.. automodule:: batchflow.models.tf.squeezenet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
