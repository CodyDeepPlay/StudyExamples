===
VGG
===

.. automodule:: batchflow.models.tf.vgg
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
