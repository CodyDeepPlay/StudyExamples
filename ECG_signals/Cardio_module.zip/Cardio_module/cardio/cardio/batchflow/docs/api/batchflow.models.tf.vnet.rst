====
VNet
====

.. automodule:: batchflow.models.tf.vnet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
