==========
TorchModel
==========

.. automodule:: batchflow.models.torch.base
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:

.. automethod:: batchflow.models.torch.TorchModel._make_inputs
