======
Models
======

.. toctree::

    batchflow.models.torch.base
    batchflow.models.torch.vgg
    batchflow.models.torch.resnet
    batchflow.models.torch.squeezenet
    batchflow.models.torch.unet
