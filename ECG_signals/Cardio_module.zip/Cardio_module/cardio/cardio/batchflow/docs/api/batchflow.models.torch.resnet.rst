======
ResNet
======

.. automodule:: batchflow.models.torch.resnet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
