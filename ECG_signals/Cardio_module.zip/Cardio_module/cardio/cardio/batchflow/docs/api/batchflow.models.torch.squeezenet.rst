==========
SqueezeNet
==========

.. automodule:: batchflow.models.torch.squeezenet
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
