===
VGG
===

.. automodule:: batchflow.models.torch.vgg
    :member-order: bysource
    :members:
    :undoc-members:
    :show-inheritance:
