Named expressions
-----------------

.. toctree::
   :maxdepth: 2

.. automodule:: batchflow.named_expr
    :member-order: bysource
    :members:
    :undoc-members:
