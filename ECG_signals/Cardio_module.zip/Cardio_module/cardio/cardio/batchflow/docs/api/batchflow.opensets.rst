================
dataset.opensets
================


MNIST
-----

.. autoclass:: batchflow.opensets.MNIST
    :members:
    :undoc-members:
    :show-inheritance:


CIFAR10
-------

.. autoclass:: batchflow.opensets.CIFAR10
    :members:
    :undoc-members:
    :show-inheritance:


CIFAR100
--------

.. autoclass:: batchflow.opensets.CIFAR100
    :members:
    :undoc-members:
    :show-inheritance:


