Pipeline
--------

.. toctree::
   :maxdepth: 2

.. autoclass:: batchflow.Pipeline
    :members:
    :undoc-members:
