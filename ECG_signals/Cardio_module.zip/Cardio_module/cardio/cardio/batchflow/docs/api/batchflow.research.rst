================
dataset.research
================


Research
--------

.. autoclass:: batchflow.research.Research
    :members:
    :undoc-members:
    :member-order: bysource

ExecutableUnit
--------------

.. autoclass:: batchflow.research.research.Executable

Grid
----

.. autoclass:: batchflow.research.Grid
    :members:
    :undoc-members:

Option
------

.. autoclass:: batchflow.research.Option
    :members:
    :undoc-members:

KV
--

.. autoclass:: batchflow.research.KV
    :members:
    :undoc-members:

ConfigAlias
-----------

.. autoclass:: batchflow.research.ConfigAlias
    :members:
    :undoc-members:
