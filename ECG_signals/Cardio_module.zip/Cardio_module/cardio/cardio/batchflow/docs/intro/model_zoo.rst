=========
Model zoo
=========

.. toctree::
   :maxdepth: 4

   model_zoo_tf
   model_zoo_torch
