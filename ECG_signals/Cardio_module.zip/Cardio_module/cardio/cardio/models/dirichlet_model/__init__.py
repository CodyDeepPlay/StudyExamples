"""Contains dirichlet model class."""

from .dirichlet_model import DirichletModel, concatenate_ecg_batch
