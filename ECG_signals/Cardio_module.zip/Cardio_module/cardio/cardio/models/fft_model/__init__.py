"""Contains fft model class."""

from .fft_model import FFTModel
