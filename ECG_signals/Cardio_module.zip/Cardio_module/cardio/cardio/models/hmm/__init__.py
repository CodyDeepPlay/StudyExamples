"""Contains HMM annotation model class."""
from .hmm import HMModel, prepare_hmm_input
