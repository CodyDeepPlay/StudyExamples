"""Contains ECG pipelines."""

from .pipelines import *  # pylint: disable=wildcard-import
