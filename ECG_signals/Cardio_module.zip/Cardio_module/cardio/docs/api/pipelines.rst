=========
Pipelines
=========

dirichlet_train_pipeline
------------------------

.. autofunction:: cardio.pipelines.dirichlet_train_pipeline

dirichlet_predict_pipeline
--------------------------

.. autofunction:: cardio.pipelines.dirichlet_predict_pipeline

hmm_preprocessing_pipeline
--------------------------

.. autofunction:: cardio.pipelines.hmm_preprocessing_pipeline

hmm_train_pipeline
------------------

.. autofunction:: cardio.pipelines.hmm_train_pipeline

hmm_predict_pipeline
--------------------

.. autofunction:: cardio.pipelines.hmm_predict_pipeline
